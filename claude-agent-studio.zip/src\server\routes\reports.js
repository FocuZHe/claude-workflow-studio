const express = require('express');
const router = express.Router();
const ReportService = require('../services/ReportService');
const { AppError } = require('../middleware/errorHandler');

router.get('/', (req, res, next) => {
  try {
    const { workflowId, search, page, limit } = req.query;
    const result = ReportService.listReports(workflowId, {
      page: parseInt(page) || 1,
      limit: Math.min(parseInt(limit) || 20, 100),
      search
    });
    res.json({
      success: true,
      data: { items: result.items, total: result.total, page: result.page, limit: result.limit }
    });
  } catch (err) { next(err); }
});

router.post('/generate', (req, res, next) => {
  try {
    const { workflowId, runId } = req.body;
    if (!workflowId || !runId) {
      throw new AppError('VALIDATION_ERROR', 'workflowId and runId are required', 400);
    }
    const result = ReportService.generateReportFromHistory(workflowId, runId);
    if (result.error) {
      throw new AppError('GENERATION_FAILED', result.error, 404);
    }
    res.json({ success: true, data: result });
  } catch (err) { next(err); }
});

router.get('/:workflowId/:runId', (req, res, next) => {
  try {
    const { workflowId, runId } = req.params;
    const content = ReportService.getReport(workflowId, runId);
    if (!content) throw new AppError('NOT_FOUND', '报告未找到', 404);
    res.json({ success: true, data: { content, workflowId, runId } });
  } catch (err) { next(err); }
});

router.get('/:workflowId/:runId/download', (req, res, next) => {
  try {
    const { workflowId, runId } = req.params;
    const content = ReportService.getReport(workflowId, runId);
    if (!content) throw new AppError('NOT_FOUND', '报告未找到', 404);
    const meta = ReportService.getReportMeta(workflowId, runId);
    res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="report-${workflowId}-${runId}.md"`);
    res.send(content);
  } catch (err) { next(err); }
});

router.delete('/:workflowId/:runId', (req, res, next) => {
  try {
    ReportService.deleteReport(req.params.workflowId, req.params.runId);
    res.json({ success: true, data: { removed: true } });
  } catch (err) { next(err); }
});

module.exports = router;
